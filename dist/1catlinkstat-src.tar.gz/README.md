# 1CatLinkStat

`1CatLinkStat` is a lightweight real-time GPU TUI for Linux NVIDIA systems. It is meant to start from the terminal as directly as `nvtop`, but adds NVLink visibility that `nvtop` does not expose on V100-class systems:

- Active NVLink channel count
- Per-link configured NVLink rate
- Aggregate configured NVLink bandwidth
- Real NVLink RX/TX totals through DCGM when the platform supports them

The runtime has no third-party Python dependencies. It talks to `libnvidia-ml.so.1` through `ctypes`.

## Start Command

After installation, start it with either of these commands:

```bash
1catlinkstat
1CatLinkStat
```

The lowercase `1catlinkstat` command is the primary terminal entrypoint.

## Features

- `nvtop`-style full-screen terminal dashboard
- Real-time GPU utilization, memory, temperature, power, clocks
- PCIe generation, width, RX, and TX visibility
- NVLink summary mode and expanded per-link mode
- Real V100 NVLink RX/TX totals via DCGM when available
- One-shot `--once` mode and `--json` mode for scripts

## Local Python Install

```bash
python3 -m pip install .
1catlinkstat
```

## APT Install

This repo now includes Debian packaging so the tool can be installed with `apt`.

1. Build the `.deb` package:

```bash
bash packaging/build-apt-package.sh
```

2. Install it with `apt`:

```bash
sudo apt install ./dist/1catlinkstat_0.1.0_all.deb
```

3. Launch it:

```bash
1catlinkstat
```

That gives you the same one-command startup style as `nvtop`, but with the extra NVLink fields.

## Usage

```bash
1catlinkstat
1catlinkstat --interval 0.5
1catlinkstat --links expanded
1catlinkstat --events 10
1catlinkstat --once
1catlinkstat --once --json
```

## True NVLink RX/TX On V100

On Tesla V100, NVML and `nvidia-smi nvlink -gt` may expose link state and configured rate but still report NVLink throughput as unsupported. `1CatLinkStat` prefers DCGM for live NVLink RX/TX totals:

```bash
sudo apt-get install -y datacenter-gpu-manager
sudo systemctl start nvidia-dcgm
1catlinkstat
```

When DCGM is available, the UI shows `live dcgm-total` and real NVLink RX/TX values.

Current V100 limitation verified on the test machine:

- Real total NVLink RX/TX per GPU: supported through DCGM fields `1011` and `1012`
- Real per-link NVLink RX/TX: not supported on this V100 setup
- Per-link configured rate and active channel count: supported

## Notes About Older GPUs

On some Pascal and Volta systems, the driver exposes NVLink speed, state, and version cleanly but does not expose live NVLink throughput through NVML or GPM. On those machines, `1CatLinkStat` first tries DCGM totals, then falls back to real-time polling plus change detection and still reports:

- Active channel count
- Per-channel configured rate
- Total configured NVLink bandwidth
- Recent link count, state, rate, and source transition events

## Development

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
```
